#include "../../../src/devicemodel/hactionarguments.h"
