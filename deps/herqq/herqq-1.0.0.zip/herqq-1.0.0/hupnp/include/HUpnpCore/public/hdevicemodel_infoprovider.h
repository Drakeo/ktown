#include "../../../src/devicemodel/hdevicemodel_infoprovider.h"
