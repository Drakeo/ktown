/* SPDX-License-Identifier: LGPL-2.1+ */
#pragma once

#include "sd-bus.h"

int bus_container_connect_socket(sd_bus *b);
