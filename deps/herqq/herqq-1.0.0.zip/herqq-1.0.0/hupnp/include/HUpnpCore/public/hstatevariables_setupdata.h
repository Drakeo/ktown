#include "../../../src/devicemodel/hstatevariables_setupdata.h"
