#include "../../../src/devicehosting/controlpoint/hcontrolpoint_configuration.h"
