#include "../../../src/devicemodel/server/hserverstatevariable.h"
