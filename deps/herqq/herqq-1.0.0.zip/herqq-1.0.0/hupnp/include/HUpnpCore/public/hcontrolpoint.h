#include "../../../src/devicehosting/controlpoint/hcontrolpoint.h"
